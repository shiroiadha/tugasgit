import sdl2.sdlgfx

print("SDL2_gfx is installed and ready to use.")
